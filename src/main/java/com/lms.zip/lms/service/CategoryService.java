package com.lms.service;

import com.lms.dto.CategoryDto;
import com.lms.dto.CommonApiResponse;
import com.lms.model.Category;
import com.lms.repository.CategoryRepository;
import com.lms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private CourseRepository courseRepository;

    public ResponseEntity<CommonApiResponse> addCategory(CategoryDto categoryDto) {
        CommonApiResponse response;

        if (categoryDto.getName() == null || categoryDto.getDescription() == null) {
            response = new CommonApiResponse(false, "Name or description cannot be null", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        try {
            Category category = CategoryDto.toEntity(categoryDto);
            category.setStatus("ACTIVE");
            Category created = categoryRepository.add(category);

            response = new CommonApiResponse(true, "Category created successfully", CategoryDto.toDto(created));
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> updateCategory(CategoryDto categoryDto) {
        CommonApiResponse response;

        if (categoryDto.getId() == 0) {
            response = new CommonApiResponse(false, "category id should not be null", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        try {

            Category category = CategoryDto.toEntity(categoryDto);
            CategoryDto updated = CategoryDto.toDto( categoryRepository.add(category) );

            response = new CommonApiResponse(true, "Category updated successfully", updated);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> deleteCategory(int categoryId) {

        CommonApiResponse response;

        if (categoryId == 0) {
            response = new CommonApiResponse(false, "Category id should not be null", categoryId);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        boolean isCourseDeactivated = courseRepository.deactiveCourseByCategory(categoryId);

        if (!isCourseDeactivated) {
            response = new CommonApiResponse(false, "Courses Deactivation Failed", null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        boolean isCategoryDeleted = categoryRepository.deleteById(categoryId);

        if (isCategoryDeleted) {
            response = new CommonApiResponse(true, "Category deleted successfully", null);
            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
        } else {
            response = new CommonApiResponse(false, "Category not found", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<CommonApiResponse> getAllCategories(String status) {
        CommonApiResponse response;

        try {
            List<Category> categories = categoryRepository.findAll(status);

            if (categories.size() == 0) {
                response = new CommonApiResponse(false, "Categories not found", null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            List<CategoryDto> categoryDtos = categories.stream()
                    .map(CategoryDto::toDto)
                    .collect(Collectors.toList());

            response = new CommonApiResponse(true, "Categories fetched successfully", categoryDtos);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
