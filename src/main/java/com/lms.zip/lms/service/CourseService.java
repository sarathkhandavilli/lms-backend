package com.lms.service;

import com.lms.dto.*;
import com.lms.exception.ResourceNotFoundException;
import com.lms.model.*;
import com.lms.repository.*;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CourseService {

    @Autowired private UserRepository userRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private CourseRepository courseRepository;
    @Autowired private CourseSectionRepository courseSectionRepository;
    @Autowired private CourseSectionTopicRepository courseSectionTopicRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private StorageRepository storageRepository;

    public ResponseEntity<CommonApiResponse> addCourse(CourseDto courseDto) {

        CommonApiResponse response;

        try {

            User mentor = userRepository.findById(courseDto.getMentorId())
                    .orElseThrow(() -> new ResourceNotFoundException("User Not Found"));

            if (mentor != null && !mentor.getRole().equals("MENTOR") ){
                throw new ResourceNotFoundException("Mentor Not Found");
            }

            Category category = categoryRepository.findById(courseDto.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

            Course course = CourseDto.toEntity(courseDto);

            MultipartFile courseThumbnail = courseDto.getThumbnail();
            if ( courseThumbnail != null) {
                String courseThumbnailName = storageRepository.store(courseDto.getThumbnail());
                course.setThumbnailName(courseThumbnailName);
            }
            course.setMentorId(mentor.getId());
            course.setCategoryId(category.getId());
            course.setStatus("ACTIVE");

            CourseDto created = CourseDto.toDto(courseRepository.save(course));
            response = new CommonApiResponse(true, "Course created Successfully", created);
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> addCourseSection(CourseSectionDto dto) {

        CommonApiResponse response;

        try {
            Course course = courseRepository.findById(dto.getCourseId())
                    .orElseThrow(() -> new ResourceNotFoundException("Course not found"));

            CourseSection section = CourseSectionDto.toEntity(dto);
            section.setCourseId(course.getId());

            CourseSectionDto created = CourseSectionDto.toDto(courseSectionRepository.add(section));
            response = new CommonApiResponse(true, "Course Section added Successfully", created);
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> addCourseSectionTopic(CourseSectionTopicDto dto) {

        CommonApiResponse response;

        try {
            CourseSection section = courseSectionRepository.findById(dto.getSectionId())
                    .orElseThrow(() -> new ResourceNotFoundException("Section not found"));

            CourseSectionTopic topic = CourseSectionTopicDto.toEntity(dto);
            topic.setSectionId(section.getId());

            CourseSectionTopicDto created = CourseSectionTopicDto.toDto(courseSectionTopicRepository.add(topic));
            response = new CommonApiResponse(true, "Course Section Topic added Successfully", created);
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseById(int id) {

        CommonApiResponse response;

        try {

            Course course = courseRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
 

            List<CourseSection> courseSections = courseSectionRepository.findByCourseId(course.getId()).orElseThrow( () -> new ResourceNotFoundException("Section not Found"));

            List<CourseSectionDto> courseSectionDtos = courseSections.stream()
            .map(CourseSectionDto::toDto)
            .collect(Collectors.toList());


            for (CourseSectionDto courseSectionDto : courseSectionDtos) {
                List<CourseSectionTopic> topics = courseSectionTopicRepository.findBySectionId(courseSectionDto.getId(),false);

                List<CourseSectionTopicDto> topicDtos = topics.stream()
                .map(CourseSectionTopicDto::toDto)
                .collect(Collectors.toList());

                courseSectionDto.setCourseSectionTopicDtos(topicDtos);

            }

            CourseDto courseDto = CourseDto.toDto(course);
            courseDto.setCourseSectionDtos(courseSectionDtos);

            response = new CommonApiResponse(true, "Course fetched successfully", courseDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
            

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseByIdAndUserId(int courseId, int userId) {

        CommonApiResponse response;

        try {
            Course course = courseRepository.findById(courseId)
                    .orElseThrow(() -> new ResourceNotFoundException("Course not found"));

            User user = userRepository.findById(userId).orElseThrow( () -> new ResourceNotFoundException("User not found"));

            boolean isEnrolled = enrollmentRepository.checkEnrollment(courseId,userId);

            List<CourseSection> courseSections = courseSectionRepository.findByCourseId(courseId)
                    .orElse(Collections.emptyList());

            List<CourseSectionDto> courseSectionDtos = courseSections.stream()
                    .map(CourseSectionDto::toDto)
                    .collect(Collectors.toList());

            boolean isUser = isEnrolled ? true : false;

            for (CourseSectionDto courseSectionDto : courseSectionDtos) {
                List<CourseSectionTopic> topics = courseSectionTopicRepository.findBySectionId(courseSectionDto.getId(),isUser);

                List<CourseSectionTopicDto> topicDtos = topics.stream()
                        .map(CourseSectionTopicDto::toDto)
                        .collect(Collectors.toList());

                courseSectionDto.setCourseSectionTopicDtos(topicDtos);
            }

            CourseDto courseDto = CourseDto.toDto(course);
            courseDto.setCourseSectionDtos(courseSectionDtos);

            response = new CommonApiResponse(true, "Course fetched successfully", courseDto);
            return new ResponseEntity<>(response, HttpStatus.OK);

            } catch (ResourceNotFoundException e) {
                response = new CommonApiResponse(false, e.getMessage(), null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
                
            } catch (Exception e) {
                response = new CommonApiResponse(false, e.getMessage(), null);
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseByStatus(String status) {

        CommonApiResponse response;

        try {
            List<Course> courses = courseRepository.findByStatus(status)
                    .orElseThrow(() -> new ResourceNotFoundException("Course with status " + status + " not found"));
            
            List<CourseDto> courseDtos = courses.stream()
            .map(CourseDto::toDto)
            .collect(Collectors.toList());

            response = new CommonApiResponse(true, "Course fetched successfully", 
            courseDtos);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseByMentor(int mentorId, String status) {

        CommonApiResponse response;

        try {

            User mentor = userRepository.findById(mentorId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found"));

            
            
            if (mentor != null && mentor.getRole().equals("LEARNER") || mentor.getRole().equals("ADMIN") ){
                throw new ResourceNotFoundException("Mentor Not Found");
            }

            List<Course> courses = courseRepository.findByMentorAndStatus(mentor.getId(), status);


            if (courses == null) {
                response = new CommonApiResponse(false, "Course not found for the given mentor and status", null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            List<CourseDto> courseDtos = courses.stream()
            .map(CourseDto::toDto)
            .collect(Collectors.toList());
            response = new CommonApiResponse(true, "Course fetched successfully", courseDtos);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseByCategory(int categoryId,String status) {

        CommonApiResponse response;

        try {
            
            List<Course> courses = courseRepository.findCourseByCategory(categoryId, status);

            List<CourseDto> courseDtos = courses.stream()
            .map(CourseDto::toDto)
            .collect(Collectors.toList());

            response = new CommonApiResponse(true, "Category fetched successfully", courseDtos);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchCourseByName(String courseName, String status) {

        CommonApiResponse response;

        try {
            List<Course> courses = courseRepository.findByNameAndStatus(courseName, status)
                    .orElseThrow(() -> new ResourceNotFoundException("No Courses Found"));

            List<CourseDto> dtos = courses.stream().map(CourseDto::toDto).collect(Collectors.toList());
            response = new CommonApiResponse(true, "Courses fetched successfully", dtos);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> deleteCourse(int courseId) {

        CommonApiResponse response;

        boolean isDeleted = courseRepository.deleteById(courseId);

        if (isDeleted) {
            response = new CommonApiResponse(true, "Course deleted successfully", null);
            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
        } else {
            response = new CommonApiResponse(false, "Course not found", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchYoutubeUrl(int coursSectionTopicId) {

        CommonApiResponse response;

        try {
            String youtubeUrl = courseSectionTopicRepository.findYoutubeUrl(coursSectionTopicId);

            if (youtubeUrl == null) {
                response = new CommonApiResponse(false, "Youtube URL not found", null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            response = new CommonApiResponse(true, "Youtube URL fetched successfully", youtubeUrl);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch(Exception e) {
            response = new CommonApiResponse(true, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    public ResponseEntity<CommonApiResponse> fetchMentorDashboardData(int mentorId) {

        CommonApiResponse response;

        try {

            User mentor = userRepository.findById(mentorId).orElseThrow( () -> new ResourceNotFoundException("User Not Found"));

            if (mentor != null && (mentor.getRole().equals("LEARNER") || mentor.getRole().equals("ADMIN") ) ){
                throw new ResourceNotFoundException("Mentor Not Found");
            }

            MentorDashBoardDto dto = new MentorDashBoardDto();

            dto.setTotalActiveCourses(courseRepository.findCountByMentorAndStatus(mentorId, "ACTIVE"));
            dto.setTotalDeletedCourses(courseRepository.findCountByMentorAndStatus(mentorId, "INACTIVE"));
            dto.setTotalCoursePurchases(courseRepository.findCountPurchasedByMentor(mentorId));
            dto.setTotalSale(mentor.getAmount());

            response = new CommonApiResponse(true, "Mentor dashboard data fetched successfully", dto);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            response = new CommonApiResponse(false, e.getMessage(), mentorId);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch(Exception e) {
            response = new CommonApiResponse(false,e.getMessage(),mentorId);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void fetchCourseImage(String thumnailName, HttpServletResponse resp) {

        Resource resource = storageRepository.load(thumnailName);

        if (resource != null) {
            try(InputStream in = resource.getInputStream()) {
                ServletOutputStream out = resp.getOutputStream();
                FileCopyUtils.copy(in, out);
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
}
