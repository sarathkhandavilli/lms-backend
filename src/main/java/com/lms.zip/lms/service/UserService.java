package com.lms.service;

import com.lms.dto.CommonApiResponse;
import com.lms.dto.LoginDto;
import com.lms.dto.MentorDetailDto;
import com.lms.dto.UserDto;
import com.lms.exception.ResourceNotFoundException;
import com.lms.model.MentorDetail;
import com.lms.model.User;
import com.lms.repository.CourseRepository;
import com.lms.repository.MentorDetailRepository;
import com.lms.repository.StorageRepository;
import com.lms.repository.UserRepository;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

@Service
public class UserService {


    @Autowired
    StorageRepository storageRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    MentorDetailRepository mentorDetailRepository;

    @Autowired
    CourseRepository courseRepository;

    public ResponseEntity<CommonApiResponse> registerUser(UserDto userDto) {

        CommonApiResponse response;

        if(userDto.getEmailId() == null ) {

            response = new CommonApiResponse(false,"email is empty", userDto);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        if (userDto.getRole() == null)  {
            response = new CommonApiResponse(false,"Role is missing",userDto);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        try {
  
            User user = userRepository.findUserByMail(userDto.getEmailId());

            if (user != null && user.getEmailId() != null) {
            response = new CommonApiResponse(false,"User with mail already exists",userDto);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
            }

            userDto.setStatus("ACTIVE");
            User userr = UserDto.toEntity(userDto);
            User registered = userRepository.add(userr);

            
            if (registered == null) {
                response = new CommonApiResponse(false,"failed to register",userDto);
                return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
            }

            response = new CommonApiResponse(true,"Registered Successfully", registered);
            return new ResponseEntity<>(response,HttpStatus.CREATED);
        } catch(Exception e) {
            response = new CommonApiResponse(true,e.getMessage(),null);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    
    public ResponseEntity<CommonApiResponse> addMentorDetail(MentorDetailDto mentorDetailDto) {

        CommonApiResponse response;

        try {

            User mentor = userRepository.findById(mentorDetailDto.getMentorId()).orElseThrow( () -> new ResourceNotFoundException("User not found"));


            if (mentor == null) {
                response = new CommonApiResponse(false, "Mentor Not found", mentor);
                return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
            }

            if (!mentor.getRole().equals("MENTOR")) {
                response = new CommonApiResponse(false, "Provided id is not mentor id", mentor);
                return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
            }
            
            MentorDetail mentorDetail = mentorDetailDto.toEntity(mentorDetailDto);
            
            if (mentorDetailDto.getProfilePic() != null) {
                String profile_pic = storageRepository.store(mentorDetailDto.getProfilePic());
                mentorDetail.setProfilePic(profile_pic);
            }

            MentorDetail detail = mentorDetailRepository.addMentorDetail(mentorDetail);

            if (detail == null) {
                response = new CommonApiResponse(false, "Failed to add Mentor detail", detail);
                return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
            }

            mentor.setMentorDetailId(detail.getId());
            userRepository.add(mentor);

            response = new CommonApiResponse(true, "Mentor detail added succesfully", detail);
            return new ResponseEntity<>(response,HttpStatus.CREATED);
        } catch(Exception e) {
            response = new CommonApiResponse(true, e.getMessage(), null);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CommonApiResponse> login(LoginDto loginDto) {

        CommonApiResponse response;

        User user = userRepository.findUserByMail(loginDto.getEmail());

        if (user == null) {
            response = new CommonApiResponse(false, "User with this mail is not registered ", null);
            return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
        }

        if (!user.getPassword().equals(loginDto.getPassword())) {
            response = new CommonApiResponse(true, "Invalid password", null);
            return new ResponseEntity<>(response,HttpStatus.UNAUTHORIZED);
        }

        if (!user.getStatus().equals("ACTIVE")) {
            response = new CommonApiResponse(false, "User is inactive", null);
            return new ResponseEntity<>(response,HttpStatus.FORBIDDEN);
        }

        response = new CommonApiResponse(true,"Login Successfull", user);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    public ResponseEntity<CommonApiResponse> getUsersByRole(String role) {

        CommonApiResponse response;

        if (role == null) {
            response = new CommonApiResponse(false, "Role is missing", role);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        try {

            List<User> users = userRepository.findUsersByRoleAndStatus(role);

            if (users.isEmpty()) {
                response = new CommonApiResponse(false,"No Users Found", users);
                return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
            }

            List<UserDto> userDtos = new ArrayList<>();
            
            for (User user : users) {
                userDtos.add(UserDto.toDto(user));
            }

            response = new CommonApiResponse(true, "Users Fetched Successfully ", userDtos);
            return new ResponseEntity<>(response,HttpStatus.OK);
        } catch(Exception e) {
            response = new CommonApiResponse(false,e.getMessage(), null);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<CommonApiResponse> getMentorById(int mentorId) {

        CommonApiResponse response;

        if (mentorId == 0) {
            response = new CommonApiResponse(false,"Missing Input",mentorId);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        try {
        User mentor = userRepository.findById(mentorId).orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (mentor != null && (mentor.getRole().equals("LEARNER") || mentor.getRole().equals("ADMIN") ) ){
                throw new ResourceNotFoundException("Mentor Not Found");
            }

        int mentorDetailId = mentor.getMentorDetailId();
        MentorDetail mentorDetail = mentorDetailRepository.findById(mentorDetailId);

        UserDto userDto  = UserDto.toDto(mentor);
        userDto.setMentorDetail(mentorDetail);

        response = new CommonApiResponse(true,"Fetched Mentor Profile",userDto);
        return new ResponseEntity<>(response,HttpStatus.OK);
        } catch(ResourceNotFoundException e) {
            response = new CommonApiResponse(false,e.getMessage(),null);
            return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
        } catch(Exception e) {
            response = new CommonApiResponse(false,e.getMessage(), null);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void fetchMentorImage(String mentorImageName, HttpServletResponse resp) {

        Resource resource = storageRepository.load(mentorImageName);

        if (resource != null) {
            try (InputStream in = resource.getInputStream()) {
                ServletOutputStream out = resp.getOutputStream();
                FileCopyUtils.copy(in, out);
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ResponseEntity<CommonApiResponse> deleteMentor(int mentorId) {

        CommonApiResponse response;

        if (mentorId == 0) {
            response = new CommonApiResponse(false,"missing data",mentorId);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        }

        try {

            User user = userRepository.findById(mentorId).orElseThrow( () -> new ResourceNotFoundException("Mentor not found"));
            
            boolean isCourseDeactivated = courseRepository.deactiveCourseByMentor(mentorId);

            if (!isCourseDeactivated) {
                response = new CommonApiResponse(false, "Courses Deactivation Failed", null);
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            boolean isMentorDeleted = userRepository.deleteById(mentorId);

            if (isMentorDeleted) {
                response = new CommonApiResponse(true, "Mentor deleted successfully", null);
                return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
            } else {
                response = new CommonApiResponse(false, "Mentor not found", null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch(Exception e) {
            response = new CommonApiResponse(false, e.getMessage(), null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
