package com.lms.model;

import lombok.Data;

@Data
public class MentorDetail {

    private int id;

    private int age;

    private int experience;

    private String qualification;

    private String profession;

    private String profilePic;

}
