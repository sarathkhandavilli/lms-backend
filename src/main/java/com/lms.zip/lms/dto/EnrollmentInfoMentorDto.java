package com.lms.dto;

import lombok.Data;

@Data
public class EnrollmentInfoMentorDto {
    
    private String learnerName;

    private double amount;

    private String enrolledTime;
}
