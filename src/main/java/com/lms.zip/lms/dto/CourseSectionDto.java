package com.lms.dto;

import java.util.List;

import com.lms.model.CourseSection;
import lombok.Data;

@Data
public class CourseSectionDto {

    private int id;

    private int courseId;

    private String sectionNo;

    private String name;

    private String description;

    private List<CourseSectionTopicDto> courseSectionTopicDtos;

    public static CourseSection toEntity(CourseSectionDto courseSectionDto) {

        CourseSection courseSection = new CourseSection();

        courseSection.setId(courseSectionDto.getId());
        courseSection.setSectionNo(courseSectionDto.getSectionNo());
        courseSection.setName(courseSectionDto.getName());
        courseSection.setDescription(courseSectionDto.getDescription());
        courseSection.setCourseId(courseSectionDto.getCourseId());

        return courseSection;
    }

    public static CourseSectionDto toDto(CourseSection courseSection) {
        CourseSectionDto courseSectionDto = new CourseSectionDto();

        courseSectionDto.setId(courseSection.getId());
        courseSectionDto.setCourseId(courseSection.getCourseId());
        courseSectionDto.setSectionNo(courseSection.getSectionNo());
        courseSectionDto.setName(courseSection.getName());
        courseSectionDto.setDescription(courseSection.getDescription());
        courseSectionDto.setCourseId(courseSection.getCourseId());

        return courseSectionDto;
    }

}
