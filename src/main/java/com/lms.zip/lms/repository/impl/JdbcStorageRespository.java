package com.lms.repository.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;
import org.springframework.core.io.FileSystemResource;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.lms.repository.StorageRepository;

@Repository
public class JdbcStorageRespository implements StorageRepository{

    @Value("${image_path}")
    private String PROFILE_PATH;
    
    @Override
    public String store(MultipartFile multipartFile) {

        String extension = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf("."));

        String fileName = UUID.randomUUID().toString().replaceAll("-", "") + extension;
        
        File filePath = new File(PROFILE_PATH,fileName);

        try (FileOutputStream out = new FileOutputStream(filePath)) {
            FileCopyUtils.copy(multipartFile.getInputStream(),out);
            return fileName;
        } catch(Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public Resource load(String fileName) {

        File filePath = new File(PROFILE_PATH,fileName);
        if (filePath.exists()) {
            return new FileSystemResource(filePath);
        }

        return null;
    }
}
