package com.lms.repository.impl;

import com.lms.model.User;
import com.lms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class JdbcUserRepository implements UserRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public Optional<User> findById(int id) {

        String sql = "SELECT * FROM users WHERE id = ?"; 

        try {
            User user = jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setFirstName(rs.getString("first_name"));
                u.setLastName(rs.getString("last_name"));
                u.setEmailId(rs.getString("email"));
                u.setPassword(rs.getString("password"));
                u.setPhoneNo(rs.getString("phone_no"));
                u.setRole(rs.getString("role"));
                u.setStatus(rs.getString("status"));
                u.setMentorDetailId(rs.getInt("mentor_detail_id"));
                u.setAmount(rs.getDouble("amount"));
                u.setMentorDetailId(rs.getInt("mentor_detail_id"));
                return u;
            }, id);

            return Optional.of(user); 
        } catch (Exception e) {
            return Optional.empty(); 
        }
    }

    @Override
    public User add(User user) {

        if (user.getMentorDetailId() ==  0 ) {

            String sql = "INSERT INTO users (first_name, last_name, email, password, phone_no, role, status) VALUES(?,?,?,?,?,?,?) RETURNING id";

            Integer generatedId = jdbcTemplate.queryForObject(sql, Integer.class,
                user.getFirstName(),
                user.getLastName(),
                user.getEmailId(),
                user.getPassword(),
                user.getPhoneNo(),
                user.getRole(),
                user.getStatus()
            );

            user.setId(generatedId);

        } else {

            String sql = "UPDATE users SET mentor_detail_id = ? WHERE id = ?";
            jdbcTemplate.update(sql,
                user.getMentorDetailId(),
                user.getId()
            );
        }

        return user;

    }

    @Override
    public User findUserByMail(String email) {

        String sql = "SELECT * FROM users WHERE email = ?";
        
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{email}, (rs, rowNum) -> {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setEmailId(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setPhoneNo(rs.getString("phone_no"));
                user.setRole(rs.getString("role"));
                user.setStatus(rs.getString("status"));
                user.setAmount(rs.getDouble("amount"));
                user.setMentorDetailId(rs.getInt("mentor_detail_id"));
                return user;
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public boolean deleteById(int mentorId) {
        String sql = "UPDATE users SET status = ? WHERE id = ?";

        int rowsAffected = jdbcTemplate.update(sql,"INACTIVE",mentorId);

        return rowsAffected > 0;
    }

    public List<User> findUsersByRoleAndStatus(String role) {
        String sql = "SELECT * FROM users WHERE role = ? AND status = ?";

        return jdbcTemplate.query(sql, new Object[]{role, "ACTIVE"}, (rs, rowNum) -> {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setFirstName(rs.getString("first_name"));
        user.setLastName(rs.getString("last_name"));
        user.setEmailId(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setPhoneNo(rs.getString("phone_no"));
        user.setRole(rs.getString("role"));
        user.setStatus(rs.getString("status"));
        user.setMentorDetailId(rs.getInt("mentor_detail_id"));
        user.setAmount(rs.getDouble("amount"));
        return user;
    });
    }

    public User update(User mentor) {
        String sql = "UPDATE users SET amount = ? WHERE id = ?";

        int rowsAffected = jdbcTemplate.update(
        sql,
        mentor.getAmount(),
        mentor.getId()
    );

    if (rowsAffected == 0) {
        throw new RuntimeException("Failed to update mentor's amount. User not found with id: " + mentor.getId());
    }

    return mentor;

    }
}
