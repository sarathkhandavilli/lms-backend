package com.lms.repository.impl;

import com.lms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import com.lms.model.Course;

@Repository
public class JdbcCourseRepository implements CourseRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Optional<Course> findById(int id) {
        String sql = "SELECT * FROM course WHERE id = ?";

        try {
            Course course = jdbcTemplate.queryForObject(sql, (rs,rowNum) -> {
                Course course1 = new Course();
                course1.setId(rs.getInt("id"));
                course1.setAuthorCourseNote(rs.getString("author_course_note"));
                course1.setStatus(rs.getString("status"));
                course1.setPrice(rs.getDouble("price"));
                course1.setPrerequisite(rs.getString("prerequisite"));
                course1.setName(rs.getString("name"));
                course1.setType(rs.getString("type"));
                course1.setAddedDateTime(rs.getTimestamp("added_date_time").toString());
                course1.setDescription(rs.getString("description"));
                course1.setDiscountInPercent(rs.getInt("discount_in_percent"));
                course1.setMentorId(rs.getInt("mentor_id"));
                course1.setCategoryId(rs.getInt("category_id"));
                course1.setThumbnailName(rs.getString("thumbnail"));

                return course1;
            },id);
            return Optional.of(course);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public Course save(Course course) {
    String sql = "INSERT INTO course (" +
             "name, description, prerequisite, author_course_note, price, discount_in_percent, " +
             " type, thumbnail, status, category_id, mentor_id) " +
             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id";

        Integer generatedId = jdbcTemplate.queryForObject(sql, Integer.class,
            course.getName(),
            course.getDescription(),
            course.getPrerequisite(),
            course.getAuthorCourseNote(),
            course.getPrice(),
            course.getDiscountInPercent(),
            course.getType().toUpperCase(),
            course.getThumbnailName(),
            course.getStatus(),
            course.getCategoryId(),
            course.getMentorId()
        );

        course.setId(generatedId);
        return course;

    }
    @Override
    public Optional<Course> findByIdAndUserId(int courseId, int userId) {
        // TODO Auto-generated method stub
        return Optional.empty();
    }
    @Override
    public Optional<List<Course>> findByStatus(String status) {
        String sql = "SELECT * FROM course WHERE status = ?";

        List<Course> courses = jdbcTemplate.query(sql, new Object[]{status}, (rs, rowNum) -> {
            Course course = new Course();
            course.setId(rs.getInt("id"));
            course.setName(rs.getString("name"));
            course.setDescription(rs.getString("description"));
            course.setPrerequisite(rs.getString("prerequisite"));
            course.setAuthorCourseNote(rs.getString("author_course_note"));
            course.setPrice(rs.getDouble("price"));
            course.setDiscountInPercent(rs.getInt("discount_in_percent"));
            course.setAddedDateTime(rs.getTimestamp("added_date_time").toString());
            course.setType(rs.getString("type"));
            course.setThumbnailName(rs.getString("thumbnail"));
            course.setStatus(rs.getString("status"));
            course.setCategoryId(rs.getInt("category_id"));
            course.setMentorId(rs.getInt("mentor_id"));
            return course;
        });

        return courses.isEmpty() ? Optional.empty() : Optional.of(courses);

    }
    @Override
    public List<Course> findByMentorAndStatus(int mentorId, String status) {
        String sql = "SELECT * FROM course WHERE mentor_id = ? AND status = ?";

        return jdbcTemplate.query(sql, new Object[]{mentorId, status}, (rs, rowNum) -> {
            Course course = new Course();
            course.setId(rs.getInt("id"));
            course.setName(rs.getString("name"));
            course.setDescription(rs.getString("description"));
            course.setPrerequisite(rs.getString("prerequisite"));
            course.setAuthorCourseNote(rs.getString("author_course_note"));
            course.setPrice(rs.getDouble("price"));
            course.setDiscountInPercent(rs.getInt("discount_in_percent"));
            course.setAddedDateTime(rs.getTimestamp("added_date_time").toString());
            course.setType(rs.getString("type"));
            course.setThumbnailName(rs.getString("thumbnail"));
            course.setStatus(rs.getString("status"));
            course.setCategoryId(rs.getInt("category_id"));
            course.setMentorId(rs.getInt("mentor_id"));
            return course;
        });
    }
    @Override
    public Optional<List<Course>> findByNameAndStatus(String courseName, String status) {
        String sql = "SELECT * FROM course WHERE name ILIKE ? AND status = ?";

        List<Course> courses = jdbcTemplate.query(sql, new Object[]{"%" + courseName + "%", status}, (rs, rowNum) -> {
            Course course = new Course();
            course.setId(rs.getInt("id"));
            course.setName(rs.getString("name"));
            course.setDescription(rs.getString("description"));
            course.setPrerequisite(rs.getString("prerequisite"));
            course.setAuthorCourseNote(rs.getString("author_course_note"));
            course.setPrice(rs.getDouble("price"));
            course.setDiscountInPercent(rs.getInt("discount_in_percent"));
            course.setAddedDateTime(rs.getTimestamp("added_date_time").toString());
            course.setType(rs.getString("type"));
            course.setThumbnailName(rs.getString("thumbnail"));
            course.setStatus(rs.getString("status"));
            course.setCategoryId(rs.getInt("category_id"));
            course.setMentorId(rs.getInt("mentor_id"));
            return course;
        });

        return courses.isEmpty() ? Optional.empty() : Optional.of(courses);
    }
    @Override
    public boolean deleteById(int id) {
        String sql = "UPDATE course SET status = ? WHERE id = ?";
        int rowsAffected = jdbcTemplate.update(sql, "INACTIVE", id);
        return rowsAffected > 0;
    }
    @Override
    public Long findCountByMentorAndStatus(int mentorId, String status) {
        String sql = "SELECT COUNT(*) FROM course WHERE mentor_id = ? AND status = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{mentorId, status}, Long.class);
    }
    @Override
    public Long findCountPurchasedByMentor(int mentorId) {
            String sql = """
            SELECT COUNT(*)
            FROM payment p
            JOIN enrollment e ON p.enrollment_id = e.enrollment_id
            JOIN course c ON e.course_id = c.id
            WHERE c.status = 'ACTIVE'
            AND e.status = 'ENROLLED'
            AND c.mentor_id = ?
        """;

        return jdbcTemplate.queryForObject(sql, Long.class, mentorId);
    }

    @Override
    public List<Course> findCourseByCategory(int categoryId, String status) {

        String sql = "SELECT * FROM course WHERE category_id = ? AND status = ? ";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Course course = new Course();
            course.setId(rs.getInt("id"));
            course.setName(rs.getString("name"));
            course.setDescription(rs.getString("description"));
            course.setPrerequisite(rs.getString("prerequisite"));
            course.setAuthorCourseNote(rs.getString("author_course_note"));
            course.setPrice(rs.getDouble("price"));
            course.setDiscountInPercent(rs.getInt("discount_in_percent"));
            course.setAddedDateTime(rs.getTimestamp("added_date_time").toString());
            course.setType(rs.getString("type"));
            course.setThumbnailName(rs.getString("thumbnail"));
            course.setStatus(rs.getString("status"));
            course.setCategoryId(rs.getInt("category_id"));
            course.setMentorId(rs.getInt("mentor_id"));
            return course;
        },categoryId,status);
    }

    public boolean deactiveCourseByCategory(int categoryId) {

        String sql = "UPDATE course SET status = ? WHERE status = ? AND category_id = ?";

        int rowsAffected = jdbcTemplate.update(sql,"INACTIVE","ACTIVE",categoryId);

        return rowsAffected >= 0;

    }

    public boolean deactiveCourseByMentor(int mentorId) {

        String sql = "UPDATE course SET status = ? WHERE status = ? AND mentor_id = ?";

        int rowsAffected = jdbcTemplate.update(sql,"INACTIVE","ACTIVE",mentorId);

        return rowsAffected >= 0;

    }

}
